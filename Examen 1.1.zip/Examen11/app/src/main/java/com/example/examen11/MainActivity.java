package com.example.examen11;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
Button btn_Regresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_Regresar=findViewById(R.id.btnRegresar);

        final EditText editText = findViewById(R.id.editText1),
                editText2 = findViewById(R.id.editText2);
        Button button = findViewById(R.id.button);
        btn_Regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Caratula.class);
                startActivity(intent);

            }
        });
        button.setOnClickListener (new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String numero1String = editText.getText().toString(),
                        numero2String = editText2.getText().toString();

                if (numero1String.equals("") || numero2String.equals("")) {

                    return;
                }


                int numero1 = Integer.parseInt(numero1String),
                        numero2 = Integer.parseInt(numero2String);

                int suma = numero1 + numero2;
                Intent intent = new Intent(MainActivity.this, Actividad2.class);

                intent.putExtra("suma", suma);


                startActivity(intent);


            }

        });

    }
}